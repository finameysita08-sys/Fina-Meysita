<?php
require 'koneksi.php';
// Ambil data dari tblmhs
$result = mysqli_query($conn, "SELECT * FROM tblmhs");
?>
<!DOCTYPE html>
<html>
<head>
<title>Halaman Admin</title>
</head>
<body>
<h2>Daftar Mahasiswa</h2>
<a href="tambah.php">Tambah Data</a>
<form action="" method="get">
<input type="text" name="keyword" size="40" autofocus placeholder="Masukkan keyword
pencarian" autocomplete="off">
<button type="submit" name="cari">Cari</button>
</form>
<table border="1" cellpadding="5" cellspacing="0">
<tr>
<th>No.</th>
<th>Aksi</th>
<th>Foto</th>
<th>NRP</th>
<th>Nama</th>
<th>Email</th>
<th>Tanggal Lahir</th>
<th>Jurusan</th>
<th>Kontak</th>
</tr>
<?php
$i=1;
// Ambil data (fetch) tblmhs dari object result
// mysqli_fetch_assoc() => mengembalikan array asosiatif
while ($row = mysqli_fetch_assoc($result)) :
?>
<tr>
<td><?php echo $i++ ; ?></td>
<td>
<a href="edit.php?id=<?php echo $row['id']; ?> ">Edit</a>
<a href="hapus.php?id=<?php echo $row['id'];?>" > Delete</a>
</td>
<td>
<img src="gambar/<?php echo $row["foto"]?>" width="70">
</td>
<td><?php echo $row["nama"]?></td>
<td><?php echo $row["nrp"]?></td>
<td><?php echo $row["email"]?></td>
<td><?php echo $row["tgllahir"]?></td>
<td><?php echo $row["jurusan"]?></td>
<td><?php echo $row["kontak"]?></td>
</tr>
<?php
endwhile
?>
</table>
</body>
</html>