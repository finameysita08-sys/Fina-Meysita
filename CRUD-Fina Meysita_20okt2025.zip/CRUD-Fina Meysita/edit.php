<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Data Mahasiswa</title>
</head>
<body>
<h2>Edit Data Mahasiswa</h2>
<a href="index.php">Kembali</a><br><br>
<form action="proses_edit.php" method="post">
<?php
require 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($conn,"select * from tblmhs where id='$id'");
while($d = mysqli_fetch_assoc($data)){
?>
<table>
<tr>
<td><input type="hidden" name="id" value="<?php echo $d['id']; ?>">
<label for="nrp"> NRP </label></td>
<td>
<input type="text" name="nrp" id="nrp" value="<?php echo $d['nrp']; ?>" required>
</td>
</tr>
<tr>
<td><label for="nama"> Nama </label></td>
<td>
<input type="text" name="nama" id="nama" value="<?php echo $d['nama']; ?>" required>
</td>
</tr>
<tr>
<td><label for="email"> Email </label></td>
<td>
<input type="email" name="email" id="email" value="<?php echo $d['email']; ?>" required>
</td>
</tr>
<tr>
<td><label for="tgl_lahir"> Tanggal Lahir </label></td>
<td>
<input type="date" name="tgllahir" id="tgllahir" value="<?php echo $d['tgllahir']; ?>"
required>
</td>
</tr>
<tr>
<td><label for="jurusan"> Jurusan </label></td>
<td>
<input type="text" name="jurusan" id="jurusan" value="<?php echo $d['jurusan']; ?>"
required>
</td>
</tr>
<tr>
<td><label for="kontak"> Kontak </label></td>
<td>
<input type="text" name="kontak" id="kontak" value="<?php echo $d['kontak']; ?>">
</td>
</tr>
<tr>
<td><label for="foto"> Foto </label></td>
<td>
<input type="text" name="foto" id="foto" value="<?php echo $d['foto']; ?>">
</td>
</tr>
<tr>
<td></td>
<td><button type="submit" name="submit">Edit Data</button>
</td>
</tr>
</table>
</form>
<?php
}
?>
</body>
</html>