<?php
// koneksi database
require 'koneksi.php';
// menangkap data yang di kirim dari form
// cek apakah tombol submit sudah ditekan atau belum
if(isset($_POST["submit"])) {
// ambil data dari tiap elemen dalam form
$id = $_POST["id"];
$nrp = htmlspecialchars($_POST["nrp"]);
$nama = htmlspecialchars($_POST["nama"]);
$email = htmlspecialchars($_POST["email"]);
$tgllahir = date("Y-m-d", strtotime($_POST["tgl_lahir"]));
$jurusan = htmlspecialchars($_POST["jurusan"]);
$kontak = htmlspecialchars($_POST["kontak"]);
$foto = $_POST["foto"];
// query update data
$query="UPDATE tblmhs SET
nrp='$nrp', nama='$nama', email='$email', tgllahir='$tgllahir', jurusan='$jurusan',
kontak='$kontak', foto='$foto' where id='$id'";
mysqli_query($conn, $query);
// cek apakah data berhasil diedit atau tidak
if(mysqli_affected_rows($conn) > 0) {
echo "<script language='javascript'>
alert ('Data mahasiswa berhasil diedit');
document.location='index.php';
</script>";
}
Else {
echo "<script language='javascript'>
alert ('Data mahasiswa gagal diedit');
</script>";
echo mysqli_error($conn);
} }
?>