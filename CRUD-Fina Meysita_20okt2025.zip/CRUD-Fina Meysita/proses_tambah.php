<?php
// koneksi database
require 'koneksi.php';
// menangkap data yang di kirim dari form
// cek apakah tombol submit sudah ditekan atau belum
if(isset($_POST["submit"])) {
// ambil data dari tiap elemen dalam form
$nrp = htmlspecialchars($_POST["nrp"]);
$nama = htmlspecialchars($_POST["nama"]);
$email = htmlspecialchars($_POST["email"]);
$tgl_lahir = date("Y-m-d", strtotime($_POST["tgl_lahir"]));
$jurusan = htmlspecialchars($_POST["jurusan"]);
$kontak = htmlspecialchars($_POST["kontak"]);
$foto = $_POST["foto"];
// query insert data
$query="INSERT INTO tblmhs VALUES
('', '$nrp', '$nama', '$email', '$tgl_lahir', '$jurusan', '$kontak', '$foto')";
mysqli_query($conn, $query);
// cek apakah data berhasil ditambahkan atau tidak
if(mysqli_affected_rows($conn) > 0) {
echo "<script language='javascript'>
alert ('Data mahasiswa berhasil ditambahkan');
document.location='index.php';
</script>";
}
else
{
echo "<script language='javascript'>
alert ('Data mahasiswa gagal ditambahkan');
</script>";
echo mysqli_error($conn);
}
}
?>