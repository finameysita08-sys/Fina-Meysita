<?php
$hosting="localhost";
$username="root";
$password="";
$database="dbmhs";
$conn = mysqli_connect($hosting, $username, $password, $database) or die ("Koneksi
database utama gagal");
?>