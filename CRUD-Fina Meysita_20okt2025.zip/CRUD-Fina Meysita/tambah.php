<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Data Mahasiswa</title>
</head>
<body>
<h2>Tambah Data Mahasiswa</h2>
<a href="index.php">Kembali</a><br><br>
<form action="proses_tambah.php" method="post">
<table>
<tr>
<td><label for="nrp"> NRP </label></td>
<td><input type="text" name="nrp" id="nrp" required></td>
</tr>
<tr>
<td><label for="nama"> Nama </label></td>
<td><input type="text" name="nama" id="nama" required ></td>
</tr>
<tr>
<td><label for="email"> Email </label></td>
<td><input type="email" name="email" id="email" required></td>
</tr>
<tr>
<td><label for="tgl_lahir"> Tanggal Lahir </label></td>
<td><input type="date" name="tgl_lahir" id="tgl_lahir" required></td>
</tr>
<tr>
<td><label for="jurusan"> Jurusan </label></td>
<td><input type="text" name="jurusan" id="jurusan" required></td>
</tr>
<tr>
<td><label for="kontak"> Kontak </label></td>
<td><input type="text" name="kontak" id="kontak"></td>
</tr>
<tr>
<td><label for="foto"> Foto </label></td>
<td><input type="text" name="foto" id="foto"></td>
</tr>
<tr>
<td></td><td>
<button type="submit" name="submit">Tambah Data</button>
</td>
</tr>
</table>
</form>
</body>
</html>